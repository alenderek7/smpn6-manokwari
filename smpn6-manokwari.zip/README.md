SMP Negeri 6 Manokwari — Portal Dokumentasi (React + Tailwind)
--------------------------------------------------------------
Files included:
- src/App.jsx         (main component)
- src/main.jsx
- src/index.css       (tailwind imports)
- public/index.html

Quick start (recommended: use Node.js + npm/yarn):
1. npm install
2. npx tailwindcss init -p
3. Configure tailwind.config.js to include ./index.html and ./src/**/*.{js,jsx}
4. npm run dev
For deployment use Vercel or Netlify. Replace the demo uploader in App.jsx with your storage backend (Firebase/S3).
