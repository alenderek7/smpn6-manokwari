import React from 'react'
export default function Home({onNav}){
  return (
    <div className="grid md:grid-cols-3 gap-6">
      <div className="md:col-span-2 bg-white p-6 rounded-2xl shadow">
        <h1 className="text-2xl font-semibold mb-2">Selamat Datang di Portal Akreditasi</h1>
        <p className="text-gray-600 mb-4">Portal ini membantu mengumpulkan dokumentasi yang diperlukan untuk proses akreditasi SMP Negeri 6 Manokwari.</p>

        <div className="flex gap-3 mb-4">
          <button onClick={()=>onNav('dok')} className="px-4 py-2 rounded bg-green-600 text-white">Unggah / Dokumentasi</button>
          <button onClick={()=>onNav('profil')} className="px-4 py-2 rounded border">Lihat Profil</button>
        </div>

        <section className="mt-4">
          <h3 className="font-semibold mb-2">Panduan Singkat</h3>
          <ol className="list-decimal list-inside text-sm text-gray-600">
            <li>Periksa daftar persyaratan akreditasi di halaman Dokumentasi.</li>
            <li>Unggah foto, PDF, dan bukti pendukung pada menu Dokumentasi.</li>
            <li>Gunakan tag yang konsisten supaya mudah dicari.</li>
          </ol>
        </section>
      </div>

      <aside className="bg-white p-6 rounded-2xl shadow">
        <h4 className="font-semibold">Statistik</h4>
        <div className="mt-3 text-sm text-gray-600">Total dok: 0 (demo)</div>
        <div className="mt-4">
          <h5 className="font-medium">Kontak Sekolah</h5>
          <div className="text-sm text-gray-600 mt-1">SMP Negeri 6 Manokwari<br/>Jl. Example No.123 — Manokwari</div>
        </div>
      </aside>
    </div>
  )
}