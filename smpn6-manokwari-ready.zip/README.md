SMPN6 Manokwari — Ready-to-upload repository
-------------------------------------------
This package is prepared for quick upload to GitHub and deploy on Vercel.

Quick steps (from your GitHub repo page):
1. Create a new repo named `smpn6-manokwari`.
2. Upload all files from this ZIP (use 'Add file' -> 'Upload files').
3. Commit changes.
4. On Vercel: New Project -> Import Git Repository -> choose your repo -> Deploy.
5. After build completes, your site will be available at https://<your-project>.vercel.app

Notes:
- The upload feature in the Dokumentasi page is a browser-only demo (files stored as Data URLs).
- To enable server upload, integrate Firebase Storage / S3 and secure with authentication.
- Run locally: install node, then `npm install` and `npm run dev` (Vite).
