import React, { useState, useRef } from "react";

// SMPN6 Manokwari - Single-file React component template
// Tailwind CSS required in the host project.
// This component is a small CMS-like front-end for uploading and showing
// accreditation documentation (images, PDFs). It includes a client-side
// uploader that can be wired to Firebase Storage or any REST endpoint.

// USAGE
// 1. Create a React app (Vite / Create React App). Install Tailwind and enable it.
// 2. Drop this file as `src/App.jsx` (or adapt).
// 3. For real uploads, follow the TODO markers to wire your storage backend
//    (Firebase Storage, S3 presigned uploads, or your school's CMS endpoint).

export default function App() {
  const [route, setRoute] = useState("home");
  const [docs, setDocs] = useState(() => sampleDocs());
  const [query, setQuery] = useState("");
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const fileRef = useRef();
  const titleRef = useRef();
  const tagRef = useRef();

  // Simple in-memory add (replace with real backend integration)
  function handleLocalUpload(e) {
    e.preventDefault();
    const file = fileRef.current.files[0];
    const title = titleRef.current.value || file?.name || "Dokumen Baru";
    const tag = tagRef.current.value || "Umum";
    if (!file) return alert("Pilih file untuk diunggah terlebih dahulu.");

    // Demo uploader: convert file to object URL and store metadata locally.
    setUploading(true);
    setProgress(10);

    const reader = new FileReader();
    reader.onload = function (ev) {
      // create a fake upload delay to show progress
      let p = 10;
      const interval = setInterval(() => {
        p += Math.random() * 25;
        if (p >= 95) {
          clearInterval(interval);
          // create doc object
          const newDoc = {
            id: Date.now().toString(),
            title,
            tag,
            filename: file.name,
            size: file.size,
            type: file.type,
            url: ev.target.result,
            uploadedAt: new Date().toISOString(),
          };
          setDocs((s) => [newDoc, ...s]);
          setUploading(false);
          setProgress(100);
          setTimeout(() => setProgress(0), 600);
        } else {
          setProgress(Math.min(95, Math.round(p)));
        }
      }, 250);
    };
    reader.readAsDataURL(file);
  }

  // TODO: Replace this function with your backend upload code (Firebase/S3/etc.)
  // Example (Firebase): use firebase/storage `uploadBytesResumable` and update progress
  // Use server-side authentication for security.

  function handleDelete(id) {
    if (!confirm("Hapus dokumen ini? Tindakan ini tidak dapat dibatalkan.")) return;
    setDocs((s) => s.filter((d) => d.id !== id));
  }

  function filteredDocs() {
    return docs.filter(
      (d) =>
        d.title.toLowerCase().includes(query.toLowerCase()) ||
        d.tag.toLowerCase().includes(query.toLowerCase()) ||
        d.filename.toLowerCase().includes(query.toLowerCase())
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white border-b shadow-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-md bg-gradient-to-br from-green-500 to-blue-600 flex items-center justify-center text-white font-bold">S6</div>
              <div>
                <h1 className="text-lg font-semibold">SMP Negeri 6 Manokwari</h1>
                <p className="text-xs text-gray-500">Portal Dokumentasi & Akreditasi</p>
              </div>
            </div>

            <nav className="flex items-center gap-2">
              <NavButton active={route === "home"} onClick={() => setRoute("home")}>Beranda</NavButton>
              <NavButton active={route === "upload"} onClick={() => setRoute("upload")}>Unggah Dokumen</NavButton>
              <NavButton active={route === "gallery"} onClick={() => setRoute("gallery")}>Galeri</NavButton>
              <NavButton active={route === "accred"} onClick={() => setRoute("accred")}>Persyaratan Akreditasi</NavButton>
              <NavButton active={route === "admin"} onClick={() => setRoute("admin")}>Admin</NavButton>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {route === "home" && (
          <section>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="md:col-span-2 bg-white p-6 rounded-2xl shadow">
                <h2 className="text-2xl font-semibold mb-3">Selamat Datang</h2>
                <p className="text-gray-600 mb-4">Portal ini dibuat untuk mengumpulkan dokumentasi, bukti fisik, dan dokumen pendukung yang diperlukan dalam proses akreditasi SMP Negeri 6 Manokwari. Anda dapat mengunggah foto, PDF, dan file lain sesuai kebutuhan.</p>

                <div className="flex gap-3">
                  <button onClick={() => setRoute("upload")} className="px-4 py-2 rounded-lg bg-blue-600 text-white font-medium">Unggah Sekarang</button>
                  <button onClick={() => setRoute("accred")} className="px-4 py-2 rounded-lg border">Lihat Persyaratan</button>
                </div>

                <div className="mt-6 border rounded-lg p-4 bg-gray-50">
                  <h3 className="font-semibold">Pencarian Cepat Dokumen</h3>
                  <div className="mt-3 flex gap-2">
                    <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Cari judul, tag, atau nama file" className="flex-1 rounded-lg border px-3 py-2" />
                    <button onClick={() => setQuery("")} className="px-4 py-2 rounded-lg border">Bersihkan</button>
                  </div>
                </div>
              </div>

              <aside className="bg-white p-6 rounded-2xl shadow">
                <h3 className="font-semibold">Statistik Singkat</h3>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <StatCard title="Total Dokumen" value={docs.length} />
                  <StatCard title="Foto / Media" value={docs.filter(d=>d.type.startsWith('image')).length} />
                  <StatCard title="PDF / Dokumen" value={docs.filter(d=>d.type==='application/pdf').length} />
                  <StatCard title="Terakhir Unggah" value={docs[0]?.uploadedAt ? new Date(docs[0].uploadedAt).toLocaleString() : '-'} />
                </div>

                <div className="mt-6">
                  <h4 className="font-medium">Kontak Sekolah</h4>
                  <p className="text-sm text-gray-600">SMP Negeri 6 Manokwari<br />Jl. Example No.123 — Manokwari</p>
                </div>
              </aside>
            </div>

            <div className="mt-8">
              <h3 className="text-lg font-semibold mb-3">Dokumen Terbaru</h3>
              <DocList docs={filteredDocs().slice(0,6)} onDelete={handleDelete} onOpen={(d)=>{window.open(d.url,'_blank')}} />
            </div>
          </section>
        )}

        {route === "upload" && (
          <section className="bg-white p-6 rounded-2xl shadow">
            <h2 className="text-xl font-semibold mb-4">Unggah Dokumentasi / Bukti</h2>
            <form onSubmit={handleLocalUpload} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Judul</label>
                <input ref={titleRef} placeholder="Contoh: Foto Ruang Kelas A" className="w-full rounded-lg border px-3 py-2" />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Kategori / Tag</label>
                <input ref={tagRef} placeholder="Contoh: Infrastruktur, Kesiswaan, Kurikulum" className="w-full rounded-lg border px-3 py-2" />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Pilih File</label>
                <input ref={fileRef} type="file" className="w-full" />
                <p className="text-xs text-gray-500 mt-1">Format yang disarankan: JPG, PNG, PDF. Maks 10 MB (atur di backend saat implementasi).</p>
              </div>

              <div className="flex items-center gap-3">
                <button type="submit" disabled={uploading} className="px-4 py-2 rounded-lg bg-green-600 text-white">{uploading ? 'Mengunggah...' : 'Unggah'}</button>
                <button type="button" onClick={()=>{fileRef.current.value=''; titleRef.current.value=''; tagRef.current.value='';}} className="px-4 py-2 rounded-lg border">Reset</button>
                <div className="flex-1">
                  {uploading && (
                    <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                      <div style={{width: `${progress}%`}} className="h-3 bg-blue-600"></div>
                    </div>
                  )}
                </div>
              </div>

              <div className="text-sm text-gray-500">Catatan: Untuk implementasi riil, ganti fungsi upload di file ini dengan koneksi ke Firebase Storage atau endpoint server yang aman. Pastikan autentikasi untuk mencegah unggah anonim jika diperlukan.</div>
            </form>

            <div className="mt-6">
              <h3 className="font-semibold">Pratinjau Dokumen Terkini</h3>
              <DocList docs={docs.slice(0,8)} onDelete={handleDelete} onOpen={(d)=>window.open(d.url,'_blank')} />
            </div>
          </section>
        )}

        {route === "gallery" && (
          <section>
            <h2 className="text-xl font-semibold mb-4">Galeri</h2>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
              {docs.filter(d=>d.type.startsWith('image')).length===0 && (
                <div className="col-span-full bg-white p-6 rounded-lg shadow text-gray-500">Tidak ada foto. Unggah foto kegiatan sekolah untuk mengisi galeri.</div>
              )}
              {docs.filter(d=>d.type.startsWith('image')).map(d=> (
                <div key={d.id} className="bg-white rounded-lg overflow-hidden shadow">
                  <img src={d.url} alt={d.title} className="w-full h-48 object-cover" />
                  <div className="p-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-medium">{d.title}</div>
                        <div className="text-xs text-gray-500">{d.tag} • {formatSize(d.size)}</div>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={()=>window.open(d.url,'_blank')} className="text-sm px-2 py-1 rounded border">Lihat</button>
                        <button onClick={()=>handleDelete(d.id)} className="text-sm px-2 py-1 rounded border">Hapus</button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {route === "accred" && (
          <section className="bg-white p-6 rounded-2xl shadow">
            <h2 className="text-xl font-semibold">Persyaratan Akreditasi (Contoh)</h2>
            <p className="text-sm text-gray-600 mt-2">Gunakan daftar ini sebagai checklist. Setiap item harus memiliki bukti (foto, dokumen, laporan) yang diunggah ke portal ini.</p>

            <ol className="mt-4 list-decimal list-inside space-y-2">
              <li>Dokumen data dasar sekolah (SK pendirian, NPSN, dsb.)</li>
              <li>Struktur organisasi dan tugas/fungsi</li>
              <li>Daftar riwayat pendidikan tenaga pendidik</li>
              <li>Curriculum vitae dan dokumen kualifikasi guru</li>
              <li>Rencana kerja tahunan dan laporan kegiatan</li>
              <li>Foto kondisi fisik bangunan (kelas, ruang guru, WC, laboratorium)</li>
              <li>Bukti fasilitas penunjang (perpustakaan, laboratorium, sarpras)</li>
              <li>Dokumen kesehatan dan keselamatan lingkungan sekolah</li>
              <li>Dokumen evaluasi dan hasil belajar siswa</li>
              <li>Bukti keterlibatan masyarakat dan komite sekolah</li>
            </ol>

            <div className="mt-6">
              <h4 className="font-medium">Cara Pakai Checklist</h4>
              <ul className="list-disc ml-5 mt-2 text-sm text-gray-600 space-y-1">
                <li>Periksa tiap item, lalu unggah dokumen pendukung di menu <strong>Unggah Dokumen</strong>.</li>
                <li>Gunakan tag yang konsisten (mis. Infrastruktur, Kurikulum, Kesiswaan) agar mudah dicari.</li>
                <li>Unduh laporan / daftar dokumen (fitur backend) untuk dikompilasi saat pengajuan akreditasi.</li>
              </ul>
            </div>
          </section>
        )}

        {route === "admin" && (
          <section className="bg-white p-6 rounded-2xl shadow">
            <h2 className="text-xl font-semibold">Panel Admin (Sederhana)</h2>
            <p className="text-sm text-gray-600">Fitur admin yang aman harus diimplementasikan di server. Panel ini hanya contoh antarmuka untuk manajemen dokumen.</p>

            <div className="mt-4">
              <h3 className="font-medium">Daftar Semua Dokumen</h3>
              <DocList docs={docs} onDelete={handleDelete} onOpen={(d)=>window.open(d.url,'_blank')} showTag />
            </div>

            <div className="mt-6">
              <h4 className="font-medium">Pengaturan</h4>
              <div className="mt-3 grid sm:grid-cols-2 gap-3">
                <div className="p-3 border rounded">
                  <div className="text-sm text-gray-600">Atur batas ukuran file maksimal (contoh UI)</div>
                </div>
                <div className="p-3 border rounded">
                  <div className="text-sm text-gray-600">Kelola kategori / tag</div>
                </div>
              </div>
            </div>
          </section>
        )}
      </main>

      <footer className="border-t bg-white mt-10">
        <div className="max-w-6xl mx-auto px-4 py-6 text-sm text-gray-500">© {new Date().getFullYear()} SMP Negeri 6 Manokwari — Portal Dokumentasi. Dibuat untuk keperluan akreditasi.</div>
      </footer>
    </div>
  );
}

// ---------- Helper components ----------
function NavButton({ children, active, onClick }) {
  return (
    <button onClick={onClick} className={`px-3 py-2 rounded-md text-sm ${active ? 'bg-blue-600 text-white' : 'hover:bg-gray-100'}`}>
      {children}
    </button>
  );
}

function StatCard({ title, value }) {
  return (
    <div className="bg-white p-3 rounded-lg shadow-sm">
      <div className="text-xs text-gray-500">{title}</div>
      <div className="text-2xl font-semibold">{value}</div>
    </div>
  );
}

function DocList({ docs, onDelete, onOpen, showTag }) {
  if (!docs || docs.length === 0) return <div className="p-4 text-gray-500">Tidak ada dokumen.</div>;
  return (
    <div className="grid gap-3">
      {docs.map((d) => (
        <div key={d.id} className="bg-white p-3 rounded-lg shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded bg-gray-100 flex items-center justify-center text-xs font-medium">{d.type.split('/')[0].toUpperCase()}</div>
            <div>
              <div className="font-medium">{d.title}</div>
              <div className="text-xs text-gray-500">{d.filename} • {formatSize(d.size)} {showTag ? `• ${d.tag}` : ''}</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => onOpen(d)} className="px-3 py-1 rounded border text-sm">Buka</button>
            <button onClick={() => onDelete(d.id)} className="px-3 py-1 rounded border text-sm">Hapus</button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------- Utilities & Sample Data ----------
function formatSize(bytes) {
  if (!bytes) return '-';
  const units = ['B','KB','MB','GB'];
  let i=0; let b = bytes;
  while (b>=1024 && i<units.length-1) { b/=1024; i++; }
  return `${Math.round(b*10)/10} ${units[i]}`;
}

function sampleDocs() {
  // Small sample documents to populate the template. Replace with API fetch.
  return [
    {
      id: '1',
      title: 'Foto Ruang Kelas A',
      tag: 'Infrastruktur',
      filename: 'kelas_a.jpg',
      size: 245123,
      type: 'image/jpeg',
      url: 'https://taburapos.co/wp-content/uploads/2022/01/2.jpg',
      uploadedAt: new Date().toISOString(),
    },
    {
      id: '2',
      title: 'Laporan Kegiatan 2024',
      tag: 'Kesiswaan',
      filename: 'laporan_2024.pdf',
      size: 823412,
      type: 'application/pdf',
      url: '#',
      uploadedAt: new Date().toISOString(),
    },
    {
      id: '3',
      title: 'Foto Perpustakaan',
      tag: 'Sarana',
      filename: 'perpustakaan.jpg',
      size: 412534,
      type: 'image/jpeg',
      url: 'https://cdn.rri.co.id/berita/Manokwari/o/1723283957361-1000139695/5i8bs2ube9a1fa2.jpeg',
      uploadedAt: new Date().toISOString(),
    }
  ];
}
