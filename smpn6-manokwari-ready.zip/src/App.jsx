import React, { useState } from 'react'
import Home from './pages/Home'
import Profil from './pages/Profil'
import Dokumentasi from './pages/Dokumentasi'
import Kontak from './pages/Kontak'

export default function App(){
  const [route, setRoute] = useState('home')
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white border-b shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-md bg-gradient-to-br from-green-600 to-blue-600 flex items-center justify-center text-white font-bold">S6</div>
            <div>
              <div className="text-lg font-semibold">SMP Negeri 6 Manokwari</div>
              <div className="text-xs text-gray-500">Portal Dokumentasi & Akreditasi</div>
            </div>
          </div>
          <nav className="flex gap-2">
            <NavBtn active={route==='home'} onClick={()=>setRoute('home')}>Beranda</NavBtn>
            <NavBtn active={route==='profil'} onClick={()=>setRoute('profil')}>Profil</NavBtn>
            <NavBtn active={route==='dok'} onClick={()=>setRoute('dok')}>Dokumentasi</NavBtn>
            <NavBtn active={route==='kontak'} onClick={()=>setRoute('kontak')}>Kontak</NavBtn>
          </nav>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {route==='home' && <Home onNav={setRoute} />}
        {route==='profil' && <Profil />}
        {route==='dok' && <Dokumentasi />}
        {route==='kontak' && <Kontak />}
      </main>

      <footer className="border-t bg-white mt-10">
        <div className="max-w-6xl mx-auto px-4 py-6 text-sm text-gray-500">© {new Date().getFullYear()} SMP Negeri 6 Manokwari — Portal Dokumentasi.</div>
      </footer>
    </div>
  )
}

function NavBtn({children, active, onClick}){
  return <button onClick={onClick} className={`px-3 py-2 rounded ${active ? 'bg-blue-600 text-white' : 'hover:bg-gray-100'}`}>{children}</button>
}