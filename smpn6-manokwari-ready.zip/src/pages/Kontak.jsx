import React from 'react'
export default function Kontak(){
  return (
    <div className="bg-white p-6 rounded-2xl shadow">
      <h2 className="text-xl font-semibold mb-3">Kontak</h2>
      <p className="text-sm text-gray-600">Untuk pertanyaan terkait akreditasi: hubungi kepala sekolah atau sekretariat.</p>
      <div className="mt-3 text-sm">
        <div>Email: admin@smpn6-manokwari.sch.id (contoh)</div>
        <div>Telp: (0987) 123-456</div>
      </div>
    </div>
  )
}