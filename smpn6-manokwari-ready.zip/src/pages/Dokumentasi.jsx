import React, { useState, useRef } from 'react'

// This demo stores uploads in browser memory (Data URLs). Replace with server-side storage for production.
export default function Dokumentasi(){
  const [docs, setDocs] = useState([])
  const fileRef = useRef()
  const titleRef = useRef()

  function upload(e){
    e.preventDefault()
    const f = fileRef.current.files[0]
    const title = titleRef.current.value || (f ? f.name : 'Dokumen')
    if(!f) return alert('Pilih file dulu')
    const reader = new FileReader()
    reader.onload = (ev)=>{
      setDocs(d=>[{id:Date.now(), title, url:ev.target.result, name:f.name, size:f.size, type:f.type}, ...d])
      fileRef.current.value = ''
      titleRef.current.value = ''
    }
    reader.readAsDataURL(f)
  }

  function remove(id){ setDocs(d=>d.filter(x=>x.id!==id)) }

  return (
    <div className="bg-white p-6 rounded-2xl shadow">
      <h2 className="text-xl font-semibold mb-3">Dokumentasi Akreditasi</h2>
      <form onSubmit={upload} className="space-y-3 mb-4">
        <input ref={titleRef} placeholder="Judul (opsional)" className="w-full rounded border px-3 py-2" />
        <input ref={fileRef} type="file" className="w-full" />
        <div className="flex gap-2">
          <button className="px-4 py-2 rounded bg-blue-600 text-white">Unggah (demo)</button>
          <div className="text-xs text-gray-500 self-center">Demo: file disimpan hanya di browser. Untuk upload nyata, hubungkan ke backend.</div>
        </div>
      </form>

      <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
        {docs.length===0 && <div className="col-span-full text-gray-500">Belum ada dokumentasi. Unggah foto / file untuk mengisi daftar.</div>}
        {docs.map(d=> (
          <div key={d.id} className="bg-gray-50 rounded p-3">
            {d.type.startsWith('image') ? <img src={d.url} alt={d.title} className="w-full h-40 object-cover rounded" /> : <div className="p-6 text-sm">{d.name}</div>}
            <div className="mt-2 flex justify-between items-center">
              <div className="text-sm font-medium">{d.title}</div>
              <div className="flex gap-2">
                <a href={d.url} target="_blank" rel="noreferrer" className="text-xs px-2 py-1 border rounded">Buka</a>
                <button onClick={()=>remove(d.id)} className="text-xs px-2 py-1 border rounded">Hapus</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}