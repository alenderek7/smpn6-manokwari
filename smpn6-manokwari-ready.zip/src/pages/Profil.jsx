import React from 'react'
export default function Profil(){
  return (
    <div className="bg-white p-6 rounded-2xl shadow">
      <h2 className="text-xl font-semibold mb-3">Profil Sekolah</h2>
      <p className="text-sm text-gray-600">SMP Negeri 6 Manokwari — Visi: Terwujudnya generasi beriman dan unggul yang berwawasan lingkungan.</p>
      <div className="mt-4 grid sm:grid-cols-2 gap-4">
        <div className="p-3 border rounded">
          <div className="font-medium">Alamat</div>
          <div className="text-sm text-gray-600">Jl. Example No.123, Manokwari</div>
        </div>
        <div className="p-3 border rounded">
          <div className="font-medium">Kontak</div>
          <div className="text-sm text-gray-600">Telp: (0987) 123-456</div>
        </div>
      </div>
    </div>
  )
}